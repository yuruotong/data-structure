#include "malloc.h"
#include "stdio.h"
#include "stdlib.h"
#define STACK_INIT_SIZE 100;
#define STACKINCREMENT 10;
typedef struct Node {
	int *top;
	int *base;
	int stacksize; //��ǰ���ѷ���Ŀռ�
}SqStack;
void InitStack(SqStack &s) {
	s.base = (int*)malloc(100 * sizeof(int));
	if (!s.base) printf("s����ʧ��");
	s.top = s.base;
	s.stacksize = STACK_INIT_SIZE;
}
void GetTop(SqStack s, int &e) {
	if (s.top == s.base) printf("����");
	e = *(s.top - 1);
}
void Pop(SqStack & s) {
	if (s.top == s.base) printf("û��Ԫ��");
	s.top--;
}
void ShowAll(SqStack &s) {
	int e;
	while (s.top != s.base) {
		GetTop(s, e);
		printf("%d", e);
		Pop(s);
	}
}
void push(SqStack &s, int e) {
	if (s.top - s.base >= s.stacksize) {
		s.base = (int*)realloc(s.base, (s.stacksize + 10) * sizeof(int));
		if (!s.base) printf("����ʧ��");
		s.top = s.base + STACKINCREMENT;
	}
	*s.top++ = e;
}


int main() {
	SqStack S;
	InitStack(S);
	int in_put;
	int jinzhi;
	int linshi;
	int shang;
	printf("������һ��ʮ��������\n");
	scanf_s("%d", &in_put,1000);
	
	  linshi = in_put;
		shang = in_put;
		while (shang / 8) {
			linshi = linshi % 8;
			push(S, linshi);
			shang = shang / 8;
		}
		push(S,shang);

		ShowAll(S);
		system("pause");


	

	



	return 0;
}