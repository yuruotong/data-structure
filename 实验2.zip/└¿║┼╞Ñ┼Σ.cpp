#include "malloc.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#define STACK_INIT_SIZE 100;
#define STACKINCREMENT 10;
typedef struct Node{
int *top;
int *base;
int stacksize; //��ǰ���ѷ���Ŀռ�
}SqStack;
void InitStack(SqStack &s){
	s.base=(int*)malloc(100*sizeof(int));
	if(!s.base) printf("s����ʧ��");
	s.top=s.base;
	s.stacksize=STACK_INIT_SIZE;
}
void GetTop(SqStack s,char &e){
if(s.top==s.base) printf("����");
e=*(s.top-1);
}
void Pop(SqStack & s){
	if(s.top==s.base) printf("û��Ԫ��");
    s.top--;
}

void push(SqStack &s,char e){
	if(s.top-s.base>=s.stacksize){
		s.base=(int*)realloc(s.base,(s.stacksize+10)*sizeof(int));
		if(!s.base) printf("����ʧ��");
		s.top=s.base+STACKINCREMENT;}
	*s.top++=e;
}


int main() {
	SqStack S;
	InitStack(S);
	char linshi;
	char in_put[100];
	printf("����������");
	scanf_s("%s", in_put, 100);
	for (int i = 0; i < strlen(in_put); i++) {
		if (in_put[i] != ')'&&in_put[i] != ']') {
			push(S, in_put[i]);
		}
		else {
			GetTop(S, linshi);
			Pop(S);
			if (linshi == in_put[i] - 1 || linshi == in_put[i] - 2) continue;
			else {
				printf("���ݲ�ƥ��");
				system("pause");
				return 0;
			}

		}



	}
	if (S.top!= S.base) {
		printf("���ݲ�ƥ��");
		system("pause");
		return 0;
	}

	printf("����ƥ��");
	system("pause");
	

return 0;
}